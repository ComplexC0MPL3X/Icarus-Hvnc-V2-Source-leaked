# Pantheon-HVNC-V2-Source-leaked
![GitHub release](https://img.shields.io/github/release/ppy/osu.svg)
![CodeFactor](https://www.codefactor.io/repository/github/ppy/osu/badge)
![dev chat](https://discordapp.com/api/guilds/188630481301012481/widget.png?style=shield)
![Crowdin](https://d322cqt584bo4o.cloudfront.net/osu-web/localized.svg)
![Renovate enabled](https://img.shields.io/badge/renovate-enabled-brightgreen.svg)
![license](https://img.shields.io/github/license/mashape/apistatus.svg)
![Chat](https://badges.gitter.im/awesome-twitter-bots/Lobby.svg)

## About Pegasus / Pantheon / Skynet Rat Hvnc 
Pegasus Is a Quality Remote Administration Tool + Hvnc, it offers support for 20 Hidden browsers.Pegasus hVNC can run a hidden desktop and can execute many browsers by copying the profile of the existing user and all this is completely hidden from the user's eyes! The same goes fot apps like outlook,foxmail, and thunderbird! Pegasus also offers one of the best password recoveries for all browsers! All this makes Pegasus one of the best tools for IT / Red Team operations slient, sneaky,powerful!

![pegasus main](https://user-images.githubusercontent.com/106186548/170267556-5ebeda3b-e4f5-4c1d-a641-ca6b8b390430.gif)


**This is not a crack and not a reverse either.Pegasus / Pantheon / Skynet hVNC Source codes have been completely leaked.There are so many shitty hvncs, Pegasus / Pantheon / Skynet is one of them. I'm sharing it so that you don't pay for such things for nothing.if your have any error problems or need any other help, you can contact me via telegram. Telegram: @BONBONATHY  in the sequel are going to show up soon.....**
## Question&Answer
<details>
<summary>What is Hidden VNC</summary>
Hidden VNC is technique used by most advanced users, and by fark the most exiciting way to manage your Computer System hidden without interacting with the main desktop at all, simply because it creates a new hidden desktop.
  </details>

 <details>
<summary>Since you mentioned that the software is used by advanced users,does it imply that i won't be able to use it since i am a intermediate user </summary>
Absolutely not, the software is desinged for intermediate users as well allowing you with click of a button to manage your computer systems.
  </details>

<details>
<summary>What can i do with it?</summary>
Once the Hidden VNC is installed on your remote computer,you will be able to interact with it sliently without any pop ups.
  </details>

<details>
<summary>Is the Software compatible with all windows versions?</summary>
**Yes it is compatible with all Windows Versions 32/64 bit except Windows Xp and Vista.
  </details>

## Full Features List (Drop Down)
<details>
<summary>Features</summary>

* Clone Profile
* Hidden Desktop
* Hidden Browsers
* Hidden Chrome
* Hidden Chromodo
* Hidden SlimJet
* Hidden Sputnik
* Hidden Awast Browser
* Hidden UC Browser
* Hidden Atom Browser
* Hidden Opera Neon
* Hidden Firefox
* Hidden Edge
* Hidden Brave
* Hidden Palemoon
* Hidden Waterfox
* Hidden Opera
* Hidden 360 browser
* Hidden Comodo Dragon
* Hidden Internet Explorer
* Hidden Explorer
* Hidden Powershell
* Hidden CMD
* Hidden Outlook
* Hidden Thunderbird
* Hidden Foxmail
* Hidden Password Recovery 
  HVNC/HVNC browsers
* HRDP/HRDP browsers/Wallets
* Reverse Proxy
* UAC Exploit for Windows 11/10
* UAC Exploit for Windows 7
* Remote Desktop
* Remote Cam
* Remote Microphone
* Remote Regedit
* Remote Console
* Silent Execute
* File Manager (download,zip,unzip)
* Disable Windows Defender
* Execute on connection Tasks
* Recovery  All Chrome based Browsers
* Recovery for All Firefox based Browsers
* Recovery & Send Logs To Discord
* Startup/Schedule task Persistence
* Miner
* Watch Dog
* TaskMgr Dog
* Spam Tools
  
  Hrdp Browers

* Hrdp Chrome
* Hrdp Firefox
* Hrdp Opera
* Hrdp Brave
 

  Hrdp Wallets

* ArmoryQt
* Coinomi
* Atomic
* Exodus
* Electrum
* Jaxx
  Pegasus Builder !
* Change Assembly
* Change Exe Icon
* Change Exe Name
* Change Filename
* File Path
* Group Clients
* Mutex
* Multi Ports Supported
* Anti Debug System
* Kill Taskmgr
* Blue Screen Error
* Watch Dog
* Uac Exploit on Execution
* TaskMgr Dog
* Export as Shell Code
* Crypter Merged
* Run PE
* Obfuscate
  </details>

### Pegasus / Pantheon / Skynet Rat Hvnc  Supported Browsers 
![image](https://user-images.githubusercontent.com/106186548/170260119-d82fbfa9-d078-485c-ad1e-017b8d5a95ac.png)

![browsers](https://user-images.githubusercontent.com/106186548/170266453-9f236c28-80b4-4044-ac4a-33125f4b3142.gif)


WebGL Support - Hidden Desktop - Copy/Paste internal - Encrypted Connection - File Manager Internal - C#/C+ + (Native) Crypter Compatibility - IPV4/ DNS Support - WD Exclusion No Popups - Quality Support - Browser Profile Cloner - Process Suspension - File Manager Support Download/Upload/Create/Delete/Explore/Execute - Reverse Connection - Hidden Persistence / Startup - Random Mutex - 2FA Recovery Bypass - Reflective Stub Injection - Stub is RunPE Compatible - Process Suspension - Download / Execute (Powershell) - Windows Defender Exclusion (No Popups) - Encrypted Connection - Kill browsers individually or all - Binder - Steal Remote Clipboard - Lightweight TCP Server - UAC Exploit (No Popups) - Browser Profile Cloner S/ C/ P/ H - CMD/Powershell Prompt - Small Stub ~130kb - Quality Adjustment/ Image Resize of hVNC - Obfuscated Stub - Compressed Image Support for faster Interaction - Random Mutex for single instances - Supported Browsers & Mail Applications - Mass disconnect - online / Offline Logger

 * here is Pegasus/Pantheon HVNC or skynet?
@TheSkynetCorporation this post is for all peopledon't get scammed by buying shitty HVNC! 
**Updated Time : 25/05/2022**
## Disclaimer / ToS
Using the software in order to gain access to unauthorized computer systems is strictly prohibited and will lead to license termination.

In case of software misuse i do not have any kind of association with your activity, futhermore i will proceed terminating your license.

In addition, if the software is posted to third party forums for cracking/warez/illegal activities i will also proceed in license termination. Terms Of Service may change whenever i want, relevant update will be posted here regarding the matter.

Kindly note that the thread is only for reviews, any questions you might have regarding the software's functionality they will be answered through Issue

Your opinion always matters and it is most welcome, i encourage you to ask for new features also report any bugs you might spot. Purchasing the software you automatically accept the ToS.
