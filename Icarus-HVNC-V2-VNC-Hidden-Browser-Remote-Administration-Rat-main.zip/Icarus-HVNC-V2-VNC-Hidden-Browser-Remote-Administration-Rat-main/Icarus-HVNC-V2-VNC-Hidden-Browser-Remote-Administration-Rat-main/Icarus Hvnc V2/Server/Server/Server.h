#include "Common.h"
#include "ControlWindow.h"

BOOL StartServer(int port);