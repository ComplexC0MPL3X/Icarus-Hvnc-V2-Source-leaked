using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyTitle("Pegasus R.A.T")]
[assembly: AssemblyDescription("Pegasus Remote Control")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Skynet Software")]
[assembly: AssemblyProduct("Pegasus Full Version")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
[assembly: AssemblyTrademark("Skynet Software Corp")]
[assembly: ComVisible(false)]
[assembly: AssemblyFileVersion("1.0.1.1")]
[assembly: AssemblyVersion("1.0.1.1")]
